#include <iostream>

namespace arrfun1 {int main(); }
namespace arrfun2 {int main(); }

int main() {
using namespace std;
	arrfun1::main();
	arrfun2::main();
	return 0;
	
}
