#include <iostream>
#include <string>
using namespace std;

const int N = 4; // N 값은 바뀔 수 있음 (단 N>0 이라 가정)

// 아래와 같이 동작하는 함수 템플릿 maximum과 add_all을 작성하라 (각각 5점)





template <typename T>
T maximum(T *arr,T * Q){
	T max=arr[0];
	for(arr;arr<Q;arr++) if(*arr > max) max=*arr;
	return max;
}



template <typename T>
T add_all(T *arr,T * Q){
	T sum=arr[0];
	for(arr+1;arr+1<Q;arr++) sum=sum+*(arr+1);
	return sum;
}

int main() {
    // 개수 N만큼 여러 타입의 배열을 적절히 초기화
    int arri[N] = { 2, 1, 4, 3 };
    double arrd[N] = { 2.1, 1.2, 4.3, 3.8 };
    string arrs[N] = { "Hello", "World", "Bye", "Sky" };

    // 주어진 범위에서 최대값을 구하는 maximum 함수
    //(단, 넘기는 범위에는 최소 1개 이상의 원소가 항상 포함되어 있다고 가정)
    cout <<maximum(arri, arri + N) <<endl; // 4
    cout <<maximum(arrd, arrd + N) <<endl; // 4.3
    cout <<maximum(arrs, arrs + N) <<endl; // World
       
    // 주어진 범위의 총합을 구하는 add_all 함수 
    // (단, 단 넘기는 범위에는 최소 1개 이상의 원소가 항상 포함되어 있다고 가정)
    cout <<add_all(arri, arri + N) <<endl; // 10
    cout <<add_all(arrd, arrd + N) <<endl; // 11.4
    cout <<add_all(arrs, arrs + N) <<endl; // HelloWorldByeSky
    return 0;
}