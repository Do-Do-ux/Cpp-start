#include <iostream>
#include <array>



using namespace std;

void show_array(double a[], int n);
void reverse_array(double a[], int n);


int main() {

	const int N = 4;
    double arr[N] = { 4.6, 3.8, 2.7,5.2 }; 
	 
	show_array(arr, N);
	reverse_array(arr,N);
	show_array(arr,N);
	
	
		
	
	
}

void show_array(double a[], int n) {

	for (int i = 0; i < n; i++)
		cout << a[i] <<"; ";

	cout <<endl;
		
}

void reverse_array(double a[], int n) {
	
	for (int i = 0; i < n / 2; i++)
	{
		double temp;
		temp = a[i];
		a[i] = a[n - i - 1];
		a[n - i - 1] = temp;
		
	}
	
}



