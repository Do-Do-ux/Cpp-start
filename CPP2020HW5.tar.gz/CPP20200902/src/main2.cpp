#include <iostream>
#include <string>
using namespace std;
/*
// 리스트라는 공통적인 개념으로도 여러가지 타입의 Node 구조체 정의 가능
struct Node { int value; Node* next; }; // 정수 리스트를 구성하는 노드
struct Node { double value; Node* next; }; // 부동소수점수 리스트를 구성하는 노드
struct Node { string value; Node* next; }; // 문자열 리스트를 구성하는 노드
*/

// Node를 구조체 템플릿으로 정의하라 (5점)

// 아래 main 함수에서처럼 리스트를 만드는 데 활용할 수있는 함수 템플릿 cons를 정의하라. (15점)

// 아래 main 함수에서처럼 리스트를 출력하는 함수 템플릿 printList를 정의하라. (10점)
template<typename T>
struct Node{T a; Node* next;};

template<typename T>
Node<T>* cons(T b, Node<T>* list) {
    return new Node<T>{b,list};
}
template<typename T>
Node<T>* cons(T c){
	return new Node<T>{c,nullptr};
}
template<typename T>

void printList(Node<T>* d){
	if (d ==nullptr){
		cout<<"["<<"]"<<endl; 
		return;
	
	}
		
	
		
	
	
    
	cout<<"["<<d->a<<",";
	cout<<(d->next)->a<<",";
	cout<<((d->next)->next)->a<<"]"<<endl;
	  
	
	
}

	

int main() {
    Node<char>* list0 = nullptr;
    Node<int>* list1 = cons(2, cons(1, cons(3)));
    // Node<int>* list1 =
    // new Node<int>{2, new Node<int>{1, new Node<int>{3, nullptr}}};
    Node<double>* list2 = cons(3.1, cons(1.2, cons(2.3)));
    // Node<double>* list2 =
    // new Node<double>{3.1, new Node<double>{1.2, new Node<double>{2.3, nullptr}}};
    string s1 = "hello", s2 = "world", s3 = "happy";
    Node<string>* list3 = cons(s1, cons(s2, cons(s3))); 
    // Node<string>* list3 =
    // new Node<string>{s1, new Node<string>{s2, new Node<string>{s3, nullptr}}};

   printList(list0); // [] 를 출력하고 줄바꿈
   printList(list1); // [2,1,3] 를 출력하고 줄바꿈
   printList(list2); // [3.1,1.2,2.3] 를 출력하고 줄바꿈
   printList(list3); // [hello,world,happy] 를 출력하고 줄바꿈

    return 0;
}